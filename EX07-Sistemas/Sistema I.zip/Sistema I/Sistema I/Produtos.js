function changeImage(src) {
}

// Declara a função "changeImage" que recebe como parametro "src" (a URL da nova imagem)
document.getElementById("product-img").src = src;
// Busca no HTML o elemento que tem o ID "product-img"
// Acessa o atributo "src" (source) da tag <img>
// Substitui o valor atual pelo "src" recebido como argumento da função
// Ou seja: troca a imagem principal pelo caminho da miniatura clicada
function addToCart() {
}
alert("Produto adicionado ao carrinhol");
function buyNow() {
alert("Redirecionando para o pagamento...");
}